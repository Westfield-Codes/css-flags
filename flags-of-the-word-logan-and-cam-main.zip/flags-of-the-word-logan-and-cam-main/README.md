[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=16978159)
# css-flags
Gallery of student Flags Of The World CSS projects
Choose a flag, make a new flag folder from a copy of the Netherlands example. 
On index.html, link to your flag, and give the button the class "done"
